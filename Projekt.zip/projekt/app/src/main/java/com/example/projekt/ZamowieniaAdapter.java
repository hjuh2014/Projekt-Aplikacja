package com.example.projekt;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ZamowieniaAdapter extends RecyclerView.Adapter<ZamowienieKeep> {

    Context context;
    List<ZamowienieRecyclerView> items;
    int pieniadze;

    public ZamowieniaAdapter(Context context, List<ZamowienieRecyclerView> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public ZamowienieKeep onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ZamowienieKeep(LayoutInflater.from(context).inflate(R.layout.zamowienie_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ZamowienieKeep holder, int position) {
        holder.nazwa.setText(items.get(position).getNazwa());
        holder.cena.setText(items.get(position).getCena());
        holder.imageView.setImageResource(items.get(position).getObraz());
        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                int pomoc = Integer.parseInt(items.get(holder.getAdapterPosition()).cena);
                if (b) {
                    pieniadze = pieniadze + pomoc;
                }
                if (!b){
                    pieniadze = pieniadze - pomoc;

                }
                int mnoznik = items.get(holder.getAdapterPosition()).getSeekBar().getProgress()+1;
                int cena = Integer.parseInt(items.get(holder.getAdapterPosition()).getCenaoriginal());
                int wynik = mnoznik * (cena + pieniadze);
                items.get(holder.getAdapterPosition()).getTextView().setText(String.valueOf(wynik));


            }
        });

    }
    @Override
    public int getItemCount() {
        return items.size();
    }
}

