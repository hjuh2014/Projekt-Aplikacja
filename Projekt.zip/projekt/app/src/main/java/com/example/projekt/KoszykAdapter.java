package com.example.projekt;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class KoszykAdapter extends RecyclerView.Adapter<KoszykKeep> {

    List<KoszykRecyclerView> items;
    Context context;

    public KoszykAdapter(List<KoszykRecyclerView> items, Context context) {
        this.context = context;
        this.items = items;
    }

    @Override
    public KoszykKeep onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new KoszykKeep(LayoutInflater.from(context).inflate(R.layout.koszyk_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull KoszykKeep holder, int position) {
        holder.nazwa.setText(items.get(position).getNazwa());
        holder.cena.setText(items.get(position).getCena());
        holder.imageView.setImageResource(items.get(position).getObraz());

    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}

