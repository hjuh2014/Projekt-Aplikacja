package com.example.projekt;

import android.widget.SeekBar;
import android.widget.TextView;

public class ZamowienieRecyclerView {
    String nazwa;
    String cena;
    int obraz;
    TextView textView;
    SeekBar seekBar;
    String cenaoriginal;
    public ZamowienieRecyclerView(String nazwa, String cena, int obraz, TextView textView, SeekBar seekBar, String cenaoriginal){
        this.cena = cena;
        this.nazwa = nazwa;
        this.obraz = obraz;
        this.textView = textView;
        this.seekBar = seekBar;
        this.cenaoriginal = cenaoriginal;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getCena() {
        return cena;
    }

    public void setCena(String cena) {
        this.cena = cena;
    }

    public int getObraz() {
        return obraz;
    }

    public TextView getTextView() {
        return textView;
    }

    public void setTextView(TextView textView) {
        this.textView = textView;
    }

    public void setObraz(int obraz) {
        this.obraz = obraz;
    }

    public SeekBar getSeekBar() {
        return seekBar;
    }

    public void setSeekBar(SeekBar seekBar) {
        this.seekBar = seekBar;
    }

    public String getCenaoriginal() {
        return cenaoriginal;
    }

    public void setCenaoriginal(String cenaoriginal) {
        this.cenaoriginal = cenaoriginal;
    }
}

