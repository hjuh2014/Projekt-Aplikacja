package com.example.projekt;

import android.content.Context;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ZamowienieKeep extends RecyclerView.ViewHolder{

    TextView cena,nazwa, cena1;
    Context context;
    ImageView imageView;
    CheckBox checkBox;
    TextView textView;
    SeekBar seekBar;
    public ZamowienieKeep(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageview1);
        nazwa = itemView.findViewById(R.id.nazwa1);
        cena = itemView.findViewById(R.id.cena1);
        checkBox = itemView.findViewById(R.id.checkbox1);
        context = itemView.getContext();
        textView = itemView.findViewById(R.id.wynik);
        seekBar = itemView.findViewById(R.id.seekbar);
        cena1 = itemView.findViewById(R.id.cena);

    }
}

