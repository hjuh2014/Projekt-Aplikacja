package com.example.projekt;

public class ProduktyRecyclerView {
    int cena;
    String nazwa;
    String login;
    public ProduktyRecyclerView(String nazwa, int cena, String login) {
        this.cena = cena;
        this.nazwa = nazwa;
        this.login = login;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }
}

