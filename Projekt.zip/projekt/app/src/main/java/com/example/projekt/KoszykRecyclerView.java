package com.example.projekt;

public class KoszykRecyclerView {
    String nazwa;
    String cena;
    int obraz;


    public KoszykRecyclerView(String nazwa, String cena, int obraz) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.obraz = obraz;
    }


    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getCena() {
        return cena;
    }

    public void setCena(String cena) {
        this.cena = cena;
    }

    public int getObraz() {
        return obraz;
    }

    public void setObraz(int obraz) {
        this.obraz = obraz;
    }
}

