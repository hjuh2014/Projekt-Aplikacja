package com.example.projekt;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProduktyKeep extends RecyclerView.ViewHolder {
    TextView nazwa, cena;
    Context context;
    public ProduktyKeep(@NonNull View itemView) {
        super(itemView);
        nazwa = itemView.findViewById(R.id.Zamowienie);
        cena = itemView.findViewById(R.id.cena);
        context = itemView.getContext();
    }
}

