package com.example.projekt;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class Register extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        Button button = findViewById(R.id.register_account);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText = findViewById(R.id.Login);
                EditText editText1 = findViewById(R.id.Email);
                EditText editText2 = findViewById(R.id.Password);
                EditText editText3 = findViewById(R.id.Adres);
                EditText editText4 = findViewById(R.id.Phone_nr);
                if (editText.getText().toString().matches("")){
                    showAlertDialog(view, "Login");
                }else {
                    if (editText1.getText().toString().matches("")){
                        showAlertDialog(view, "Email");
                    }else {
                        if (editText2.getText().toString().matches("")){
                            showAlertDialog(view, "Haslo");
                        }else {
                            if (editText3.getText().toString().matches("")){
                                showAlertDialog(view, "Adres");
                            }else {
                                if (editText4.getText().toString().matches("")){
                                    showAlertDialog(view, "Nr.Telefonu");
                                }else {


                                    SQLliteHelper sqLliteHelper =  new SQLliteHelper(Register.this);
                                    SQLiteDatabase db = sqLliteHelper.getWritableDatabase();


                                    ContentValues values = new ContentValues();
                                    values.put(SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE, editText.getText().toString());
                                    values.put(SQLliteHelper.SQLscheme.PASSWORD, editText2.getText().toString());
                                    values.put(SQLliteHelper.SQLscheme.EMAIL, editText1.getText().toString());
                                    values.put(SQLliteHelper.SQLscheme.NUMBER_PH, editText4.getText().toString());
                                    values.put(SQLliteHelper.SQLscheme.ADRES, editText3.getText().toString());

                                    db.insert(SQLliteHelper.SQLscheme.TABLE_NAME, null, values);
                                    Intent intent = new Intent(Register.this, Login.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);


                                }
                            }
                        }
                    }
                }

            }
        });


    }
    public void showAlertDialog(View v, String pole){
        AlertDialog.Builder alert = new AlertDialog.Builder(Register.this);
        alert.setTitle("Bład przy wpisywaniu Danych w polu " + pole);
        alert.setMessage("Wypelnij pola odpowiednio");
        alert.create().show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i = item.getItemId();
        Intent intent12 = new Intent(this, MainActivity.class);
        Bundle extras = getIntent().getExtras();
        String email = "";
        String login = "";
        String sprawdzenie = "";
        if (extras != null){
            login = extras.getString("Login");
            email = extras.getString("Email");
            sprawdzenie = extras.getString("Bool");



        }

        switch (i){
            case R.id.strona_glowna:
                Intent intent4 = new Intent(this, MainActivity.class);
                intent4.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent4);
                break;
            case R.id.register:
                Intent intent = new Intent(this, Register.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent);
                break;
            case R.id.login:
                Intent intent1 = new Intent(this, Login.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent1);
                break;
            case R.id.about:
                Intent intent3 = new Intent(this, About.class);
                intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent3);
                break;
            case R.id.logout:
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.usun:
                SQLliteHelper sqLliteHelper = new SQLliteHelper(this);
                SQLiteDatabase db2 = sqLliteHelper.getReadableDatabase();
                if (login != null && !login.equals("")){
                    String selection = SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.Login + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.COLUMN_NAME_TITLE + " LIKE ?";
                    String [] selectionArgs = {login};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);

                }
                if (email != null && !email.equals("")){
                    String selection = SQLliteHelper.SQLscheme.EMAIL + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.EMAIL + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.EMAIL + " LIKE ?";
                    String [] selectionArgs = {email};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);
                }
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.zamowienia:
                Intent intent2 = new Intent(this, Produkty.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent2.putExtra("Login", login);
                intent2.putExtra("Email", email);
                intent2.putExtra("Bool", sprawdzenie);
                startActivity(intent2);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}

