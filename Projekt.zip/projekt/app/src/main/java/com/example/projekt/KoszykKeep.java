package com.example.projekt;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class KoszykKeep extends RecyclerView.ViewHolder {
    ImageView imageView;
    TextView nazwa, cena;
    Context context;
    public KoszykKeep(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageview);
        nazwa = itemView.findViewById(R.id.nazwa);
        cena = itemView.findViewById(R.id.cena12);
        context = itemView.getContext();
    }
}
