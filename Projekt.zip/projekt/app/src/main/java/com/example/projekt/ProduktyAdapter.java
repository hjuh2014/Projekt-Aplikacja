package com.example.projekt;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProduktyAdapter extends RecyclerView.Adapter<ProduktyKeep> {
    Context context;
    List<ProduktyRecyclerView> list;
    public ProduktyAdapter(Context context, List<ProduktyRecyclerView> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override

    public ProduktyKeep onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ProduktyKeep(LayoutInflater.from(context).inflate(R.layout.produkty_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProduktyKeep holder, int position) {
        holder.nazwa.setText("Zamówienie nr. " + list.get(position).getNazwa());
        holder.cena.setText(String.valueOf(list.get(position).getCena()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(holder.context, ProduktWybierz.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("nr.", list.get(holder.getAdapterPosition()).getNazwa());
                intent.putExtra("Login", list.get(holder.getAdapterPosition()).getLogin());
                holder.context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

