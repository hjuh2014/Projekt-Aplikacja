package com.example.projekt;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<MyViewKeep> {

    Context context;
    List<ItemsRecycler> items;
    String Login;
    String Haslo;
    String Email;
    Boolean sprawdzenie;


    public MyAdapter(Context context, List<ItemsRecycler> items, @Nullable String Login, @Nullable String Haslo, @Nullable String Email, @Nullable Boolean sprawdzenie) {
        this.context = context;
        this.items = items;
        this.Haslo = Haslo;
        this.Login = Login;
        this.Email = Email;
        this.sprawdzenie = sprawdzenie;
    }

    @Override
    public MyViewKeep onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewKeep(LayoutInflater.from(context).inflate(R.layout.item_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewKeep holder, int position) {
        holder.nazwa.setText(items.get(position).getNazwa());
        holder.cena.setText(items.get(position).getCena());
        holder.imageView.setImageResource(items.get(position).getObraz());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Intent intent;
                switch (holder.getAdapterPosition()){
                    default:
                        if (sprawdzenie == false) {
                            intent = new Intent(holder.context, Zamowienie.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            String nazwa = items.get(holder.getAdapterPosition()).getNazwa();
                            String cena = items.get(holder.getAdapterPosition()).getCena();
                            int image = items.get(holder.getAdapterPosition()).getObraz();
                            intent.putExtra("nazwa", nazwa);
                            intent.putExtra("cena", cena);
                            intent.putExtra("image", image);
                            intent.putExtra("Bool", "False");
                            holder.context.startActivity(intent);
                        } else {
                            intent = new Intent(holder.context, Zamowienie.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            String nazwa = items.get(holder.getAdapterPosition()).getNazwa();
                            String cena = items.get(holder.getAdapterPosition()).getCena();
                            int image = items.get(holder.getAdapterPosition()).getObraz();
                            intent.putExtra("nazwa", nazwa);
                            intent.putExtra("cena", cena);
                            intent.putExtra("image", image);
                            intent.putExtra("Login", Login);
                            intent.putExtra("Haslo", Haslo);
                            intent.putExtra("Email", Email);
                            String bool = "True";
                            intent.putExtra("Bool", bool);
                            holder.context.startActivity(intent);
                        }
                        break;
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}

