package com.example.projekt;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Zamowienie extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        TextView nazT;
        TextView cenT;
        TextView ilosc;
        ImageView imageView;
        Button minus;
        Button plus;
        Button zakup;
        SeekBar seekBar;
        RecyclerView recyclerView;






        String nazwa = "";
        String cena = "";
        int image = 0;
        int pieniadze = 0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zamowienie);

        Bundle extras = getIntent().getExtras();
        if (extras != null){
            nazwa = extras.getString("nazwa");
            cena = extras.getString("cena");
            image = extras.getInt("image");


        }
        nazT = findViewById(R.id.nazwa);
        cenT = findViewById(R.id.cena);
        imageView = findViewById(R.id.obraz);
        seekBar = findViewById(R.id.seekbar);
        nazT.setText(nazwa);
        cenT.setText(cena);
        imageView.setImageResource(image);
        plus = findViewById(R.id.plus);
        minus = findViewById(R.id.minus);
        ilosc = findViewById(R.id.ilosc_liczba);
        ilosc.setText(String.valueOf(seekBar.getProgress()+1));
        TextView textView1 = findViewById(R.id.wynik);
        recyclerView = findViewById(R.id.recycler_view1);
        int wynik = Integer.parseInt(cenT.getText().toString()) * (seekBar.getProgress()+1);

        textView1.setText(String.valueOf(wynik));

        List<ZamowienieRecyclerView> items = new ArrayList<ZamowienieRecyclerView>();

        items.add(new ZamowienieRecyclerView("Komputer1", "1000",R.drawable.gaming1, textView1, seekBar,cena));
        items.add(new ZamowienieRecyclerView("Komputer2", "2000",R.drawable.gaming2, textView1, seekBar,cena));
        items.add(new ZamowienieRecyclerView("Komputer3", "3000",R.drawable.gaming3, textView1, seekBar,cena));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ZamowieniaAdapter(getApplicationContext(),items));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ilosc.setText(String.valueOf(seekBar.getProgress()+1));

                recyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        int cenunia = Integer.parseInt(cenT.getText().toString());
                        int pieniadze = 0;
                        TextView textView1 = findViewById(R.id.wynik);
                        for (int j = 0; j < recyclerView.getAdapter().getItemCount(); j++) {
                            View selectedview = recyclerView.getChildAt(j);
                            CheckBox checkBox = selectedview.findViewById(R.id.checkbox1);
                            TextView textView = selectedview.findViewById(R.id.cena1);
                            if (checkBox.isChecked()){
                                pieniadze = pieniadze + Integer.parseInt(textView.getText().toString());

                            }
                        }
                        textView1.setText(String.valueOf((cenunia + pieniadze) * (seekBar.getProgress() + 1)));
                    }


                });



            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                ilosc.setText(String.valueOf(seekBar.getProgress()+1));
                recyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        int cenunia = Integer.parseInt(cenT.getText().toString());
                        TextView textView1 = findViewById(R.id.wynik);
                        int pieniadze = 0;
                        for (int j = 0; j < recyclerView.getAdapter().getItemCount(); j++) {
                            View selectedview = recyclerView.getChildAt(j);
                            CheckBox checkBox = selectedview.findViewById(R.id.checkbox1);
                            TextView textView = selectedview.findViewById(R.id.cena1);
                            if (checkBox.isChecked()){
                                pieniadze = pieniadze + Integer.parseInt(textView.getText().toString());

                            }
                        }
                        textView1.setText(String.valueOf((cenunia + pieniadze) * (seekBar.getProgress() + 1)));
                    }


                });



            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                ilosc.setText(String.valueOf(seekBar.getProgress()+1));
                recyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        int cenunia = Integer.parseInt(cenT.getText().toString());
                        TextView textView1 = findViewById(R.id.wynik);
                        int pieniadze = 0;
                        for (int j = 0; j < recyclerView.getAdapter().getItemCount(); j++) {
                            View selectedview = recyclerView.getChildAt(j);
                            CheckBox checkBox = selectedview.findViewById(R.id.checkbox1);
                            TextView textView = selectedview.findViewById(R.id.cena1);
                            if (checkBox.isChecked()){
                                pieniadze = pieniadze + Integer.parseInt(textView.getText().toString());

                            }
                        }
                        textView1.setText(String.valueOf((cenunia + pieniadze) * (seekBar.getProgress() + 1)));
                    }


                });



            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seekBar.setProgress(seekBar.getProgress()+1);
                ilosc.setText(String.valueOf(seekBar.getProgress()+1));
            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                seekBar.setProgress(seekBar.getProgress()-1);
                ilosc.setText(String.valueOf(seekBar.getProgress()+1));
            }
        });
        zakup = findViewById(R.id.zakup1);
        zakup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login1 = "";
                String email1 = "";
                String login = "";
                String email = "";
                String sprawdzenie = "";
                int image = 0;
                Bundle extras = getIntent().getExtras();
                if (extras != null){
                    sprawdzenie = extras.getString("Bool");
                }
                if (sprawdzenie != null && sprawdzenie.equalsIgnoreCase("True")){

                    if (extras != null){
                        login = extras.getString("Login");
                        email = extras.getString("Email");
                        image = extras.getInt("image");



                    }
                    if (login != null && !login.equalsIgnoreCase("")) {
                        String napis = "";
                        for (int j = 0; j < recyclerView.getAdapter().getItemCount(); j++) {
                            View selectedview = recyclerView.getChildAt(j);
                            CheckBox checkBox = selectedview.findViewById(R.id.checkbox1);
                            if (checkBox.isChecked()) {
                                if (napis.equals("")) {
                                    napis = napis + items.get(j).getNazwa();
                                }else {
                                    napis = napis + ", " + items.get(j).getNazwa();
                                }
                            }
                        }
                        SQLliteHelper sqLliteHelper = new SQLliteHelper(Zamowienie.this);
                        SQLiteDatabase db = sqLliteHelper.getWritableDatabase();
                        SQLiteDatabase db1 = sqLliteHelper.getReadableDatabase();
                        String[] projection = {
                                SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE,
                                SQLliteHelper.SQLscheme.EMAIL,

                        };
                        String selection = SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE + "=?";
                        String[] selectionArgs = {login};
                        String sortOrder = SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE + " DESC";
                        Cursor cursor = db1.query(SQLliteHelper.SQLscheme.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
                        while (cursor.moveToNext()){
                            login1 = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE));
                            email1 = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.SQLscheme.EMAIL));
                        }
                        int seekbar = seekBar.getProgress() + 1;
                        ContentValues values = new ContentValues();
                        values.put(SQLliteHelper.zamowienia.Zamowienie, "Zestaw " + nazT.getText().toString() + " z " + napis + " x " + seekbar);
                        values.put(SQLliteHelper.zamowienia.COLUMN_NAME_TITLE, login1);
                        values.put(SQLliteHelper.zamowienia.EMAIL, email1);
                        values.put(SQLliteHelper.zamowienia.Cena_Zamowienia, textView1.getText().toString());
                        values.put(SQLliteHelper.zamowienia.Obraz, image);
                        values.put(SQLliteHelper.zamowienia.Nr_Zamowienia, 0);
                        db.insert(SQLliteHelper.zamowienia.TABLE_NAME, null, values);

                        cursor.close();
                        Intent intent = new Intent(Zamowienie.this, Koszyk.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Login", login);
                        intent.putExtra("Bool", sprawdzenie);
                        intent.putExtra("Email", email);
                        startActivity(intent);
                    }

                    if (email !=null && !email.equalsIgnoreCase("")) {
                        String napis = "";
                        for (int j = 0; j < recyclerView.getAdapter().getItemCount(); j++) {
                            View selectedview = recyclerView.getChildAt(j);
                            CheckBox checkBox = selectedview.findViewById(R.id.checkbox1);
                            if (checkBox.isChecked()) {
                                if (napis.equals("")) {
                                    napis = napis + items.get(j).getNazwa();
                                }
                                napis = napis + ", " + items.get(j).getNazwa();
                            }
                        }
                        SQLliteHelper sqLliteHelper = new SQLliteHelper(Zamowienie.this);
                        SQLiteDatabase db = sqLliteHelper.getWritableDatabase();
                        SQLiteDatabase db1 = sqLliteHelper.getReadableDatabase();
                        String[] projection = {
                                SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE,
                                SQLliteHelper.SQLscheme.EMAIL,

                        };
                        String selection2 = SQLliteHelper.SQLscheme.EMAIL + "=?";
                        String[] selectionArgs1 = {email};
                        String sortOrder2 = SQLliteHelper.SQLscheme.EMAIL + " DESC";
                        Cursor cursor1 = db1.query(SQLliteHelper.SQLscheme.TABLE_NAME, projection, selection2, selectionArgs1, null, null, sortOrder2);
                        while (cursor1.moveToNext()){
                            login1 = cursor1.getString(cursor1.getColumnIndexOrThrow(SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE));
                            email1 = cursor1.getString(cursor1.getColumnIndexOrThrow(SQLliteHelper.SQLscheme.EMAIL));

                        }



                        int seekbar = seekBar.getProgress() + 1;
                        ContentValues values = new ContentValues();
                        values.put(SQLliteHelper.zamowienia.Zamowienie, "Zestaw " + nazT.getText().toString() + " z " + napis + " x " + seekbar);
                        values.put(SQLliteHelper.zamowienia.COLUMN_NAME_TITLE, login1);
                        values.put(SQLliteHelper.zamowienia.EMAIL, email1);
                        values.put(SQLliteHelper.zamowienia.Cena_Zamowienia, textView1.getText().toString());
                        values.put(SQLliteHelper.zamowienia.Obraz, image);
                        values.put(SQLliteHelper.zamowienia.Nr_Zamowienia, 0);
                        db.insert(SQLliteHelper.zamowienia.TABLE_NAME, null, values);
                        cursor1.close();
                        Intent intent = new Intent(Zamowienie.this, Koszyk.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("Login", login);
                        intent.putExtra("Bool", sprawdzenie);
                        intent.putExtra("Email", email);
                        startActivity(intent);
                    }
                } else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(Zamowienie.this);
                    alert.setMessage("Zaloguj się by dokonac zakupu");
                    alert.setCancelable(false);
                    alert.setNeutralButton("ZALOGUJ", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(Zamowienie.this, Login.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    });
                    alert.create().show();

                }
            }


        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Bundle extras = getIntent().getExtras();
        String sprawdzenie1 = "";
        if (extras != null){
            sprawdzenie1 = extras.getString("Bool");
        }
        MenuInflater inflater = getMenuInflater();
        if (sprawdzenie1 != null && sprawdzenie1.equalsIgnoreCase("True")){
            inflater.inflate(R.menu.menu_log, menu);
        }
        else {
            inflater.inflate(R.menu.menu, menu);
        }
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i = item.getItemId();
        Intent intent12 = new Intent(this, MainActivity.class);
        Bundle extras = getIntent().getExtras();
        String email = "";
        String login = "";
        String sprawdzenie = "";
        if (extras != null){
            login = extras.getString("Login");
            email = extras.getString("Email");
            sprawdzenie = extras.getString("Bool");



        }

        switch (i){
            case R.id.strona_glowna:
                Intent intent4 = new Intent(this, MainActivity.class);
                intent4.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent4);
                break;
            case R.id.register:
                Intent intent = new Intent(this, Register.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent);
                break;
            case R.id.login:
                Intent intent1 = new Intent(this, Login.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent1);
                break;
            case R.id.about:
                Intent intent3 = new Intent(this, About.class);
                intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent3);
                break;
            case R.id.logout:
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.usun:
                SQLliteHelper sqLliteHelper = new SQLliteHelper(this);
                SQLiteDatabase db2 = sqLliteHelper.getReadableDatabase();
                if (login != null && !login.equals("")){
                    String selection = SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.Login + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.COLUMN_NAME_TITLE + " LIKE ?";
                    String [] selectionArgs = {login};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);

                }
                if (email != null && !email.equals("")){
                    String selection = SQLliteHelper.SQLscheme.EMAIL + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.EMAIL + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.EMAIL + " LIKE ?";
                    String [] selectionArgs = {email};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);
                }
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.zamowienia:
                Intent intent2 = new Intent(this, Produkty.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent2.putExtra("Login", login);
                intent2.putExtra("Email", email);
                intent2.putExtra("Bool", sprawdzenie);
                startActivity(intent2);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}

