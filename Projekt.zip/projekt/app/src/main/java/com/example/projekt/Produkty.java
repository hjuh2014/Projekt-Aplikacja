package com.example.projekt;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Produkty extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.produkty);
        SQLliteHelper sqLliteHelper = new SQLliteHelper(Produkty.this);
        SQLiteDatabase db = sqLliteHelper.getReadableDatabase();
        Bundle bundle = getIntent().getExtras();
        String login = "";
        String email = "";
        if (bundle != null){
            login = bundle.getString("Login");
            email = bundle.getString("Email");
        }
        if (login != null && !login.equalsIgnoreCase("")){
            String[] projections = {
                    SQLliteHelper.produkty.Nr_Zamowienia,
                    SQLliteHelper.produkty.Cena,
                    SQLliteHelper.produkty.Login
            };
            String selection = SQLliteHelper.produkty.Nr_Zamowienia + " !=? AND " + SQLliteHelper.produkty.Login + " =?";
            String[] selectionargs = {
                    "0",
                    login
            };
            String order = SQLliteHelper.produkty.Nr_Zamowienia + " DESC";
            Cursor cursor = db.query(SQLliteHelper.produkty.TABLE_NAME, projections,selection,selectionargs,null,null, order);

            RecyclerView recyclerView = findViewById(R.id.recycler_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            List<ProduktyRecyclerView> list = new ArrayList<>();
            while (cursor.moveToNext()){
                int cena = cursor.getInt(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Cena));
                String nr = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Nr_Zamowienia));
                String login1 = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Login));
                list.add(new ProduktyRecyclerView(nr, cena, login1));
            }
            recyclerView.setAdapter(new ProduktyAdapter(getApplicationContext(), list));
        }
        if (email != null && !email.equalsIgnoreCase("")){
            String[] projections = {
                    SQLliteHelper.produkty.Nr_Zamowienia,
                    SQLliteHelper.produkty.Cena,
                    SQLliteHelper.produkty.Login
            };
            String selection = SQLliteHelper.produkty.Nr_Zamowienia + " !=? AND " + SQLliteHelper.produkty.EMAIL + " =?";
            String[] selectionargs = {
                    "0",
                    email
            };
            String order = SQLliteHelper.produkty.Nr_Zamowienia + " DESC";
            Cursor cursor = db.query(SQLliteHelper.produkty.TABLE_NAME, projections,selection,selectionargs,null,null, order);

            RecyclerView recyclerView = findViewById(R.id.recycler_view);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            List<ProduktyRecyclerView> list = new ArrayList<>();
            while (cursor.moveToNext()){
                int cena = cursor.getInt(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Cena));
                String nr = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Nr_Zamowienia));
                String login1 = cursor.getString(cursor.getColumnIndexOrThrow(SQLliteHelper.produkty.Login));
                list.add(new ProduktyRecyclerView(nr, cena, login1));
            }
            recyclerView.setAdapter(new ProduktyAdapter(getApplicationContext(), list));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_log, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int i = item.getItemId();
        Intent intent12 = new Intent(this, MainActivity.class);
        Bundle extras = getIntent().getExtras();
        String email = "";
        String login = "";
        String sprawdzenie = "";
        if (extras != null){
            login = extras.getString("Login");
            email = extras.getString("Email");
            sprawdzenie = extras.getString("Bool");



        }

        switch (i){
            case R.id.strona_glowna:
                Intent intent4 = new Intent(this, MainActivity.class);
                intent4.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent4);
                break;
            case R.id.register:
                Intent intent = new Intent(this, Register.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent);
                break;
            case R.id.login:
                Intent intent1 = new Intent(this, Login.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent1);
                break;
            case R.id.about:
                Intent intent3 = new Intent(this, About.class);
                intent3.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                this.startActivity(intent3);
                break;
            case R.id.logout:
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.usun:
                SQLliteHelper sqLliteHelper = new SQLliteHelper(this);
                SQLiteDatabase db2 = sqLliteHelper.getReadableDatabase();
                if (login != null && !login.equals("")){
                    String selection = SQLliteHelper.SQLscheme.COLUMN_NAME_TITLE + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.Login + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.COLUMN_NAME_TITLE + " LIKE ?";
                    String [] selectionArgs = {login};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);

                }
                if (email != null && !email.equals("")){
                    String selection = SQLliteHelper.SQLscheme.EMAIL + " LIKE ?";
                    String selection2 = SQLliteHelper.produkty.EMAIL + " LIKE ?";
                    String selection3 = SQLliteHelper.zamowienia.EMAIL + " LIKE ?";
                    String [] selectionArgs = {email};
                    db2.delete(SQLliteHelper.SQLscheme.TABLE_NAME, selection, selectionArgs);
                    db2.delete(SQLliteHelper.zamowienia.TABLE_NAME, selection3, selectionArgs);
                    db2.delete(SQLliteHelper.produkty.TABLE_NAME, selection2, selectionArgs);
                }
                intent12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent12);
                break;
            case R.id.zamowienia:
                Intent intent2 = new Intent(this, Produkty.class);
                intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent2.putExtra("Login", login);
                intent2.putExtra("Email", email);
                intent2.putExtra("Bool", sprawdzenie);
                startActivity(intent2);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}

